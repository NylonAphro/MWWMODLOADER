---@meta

StopWatch.running_watches = {}

---MWWSE
---@param name string
---@param completed_function function
function StopWatch:start_watch(name, completed_function, condition_args) end

function StopWatch:stop_watch(name) end

