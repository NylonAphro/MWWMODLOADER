---MWWSE
---@param self table
---@param origin_point any
---@param aim_point any
---@param hit_function any
---This function creates a raycast from the origin point to the aim point and executes the hit function when the raycast hits an object. end

---This function creates a raycast from the origin point to the aim point and executes the hit function when the raycast hits an object.
---the hit function will receive a table/list of actors hit end

---the hit function will receive a table/list of actors hit
Raycaster.cast_ray = function(self, origin_point, aim_point, hit_function) end

Raycaster.setup_game_world = function (self, context) end

