---@meta

-------------------------------------------------------------------------------
-- Encode
-------------------------------------------------------------------------------




encode = function(val, stack, tabs_) end

---MWWSE
---@param val any
---@return string|unknown
---returns a json string given a table
function json.encode(val) end





parse = function(str, idx) end

---MWWSE
---@param str any
---@return table
---returns a table given a json string
function json.decode(str) end

