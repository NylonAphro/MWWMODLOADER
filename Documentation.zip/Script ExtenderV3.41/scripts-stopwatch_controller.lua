StopWatch.running_watches = {}

---MWWSE
---@param name string
---@param completed_function function
StopWatch.start_watch = function(self, name, completed_function, condition_args) end

StopWatch.stop_watch = function(self, name) end

