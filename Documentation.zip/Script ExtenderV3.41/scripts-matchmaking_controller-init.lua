

---MWWSE
---@param region string
---@param server_type string
--- eg AUTO_JOIN_SERVER("US", "Duel")
function JOIN_SERVER(region, server_type) end

---MWWSE
---@param region string
---@param server_type string
--- eg AUTO_JOIN_SERVER("US", "Duel")
function AUTO_JOIN_SERVER(region, server_type) end

---MWWSE
---stops the auto join timer
function STOP_AUTO_JOIN() end

