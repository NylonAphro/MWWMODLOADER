scripts/matchmaking_controller/init
scripts/timer_controller/init
scripts/ui_controller/init
