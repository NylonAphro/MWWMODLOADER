This mod:
• Lets you toggle any part of the in-game HUD on/off
• Optionally shows HP numbers above people's floaty HP bars
• Shows you what map is coming up in the lobby ahead of time


Hold "ctrl" for a couple seconds in-game for a tutorial! But here is a tutorial anyway.

Hold "ctrl" then press <key> to toggle hiding/showing <some HUD element>.
Hold "shift" + "ctrl" then press <key> to show ONLY <some HUD element>.

Healthbar ("ctrl" + "n") is special. It has three modes: Numbers/Name/bar/None


CONTROLS (remember, just hold "ctrl" to see this this in-game!!):
	ctrl + n = hide Numbers/Name/bar/None for the floaty healthbar
	ctrl + c = hide Chat
	ctrl + k = hide magicKs and elements
	ctrl + m = hide MiniMap
	ctrl + p = hide Portraits
	ctrl + r = hide spell chaRge baR
	ctrl + s = hide Spellwheel
	ctrl + t = hide Timer
	
	shift + ctrl + <key> = hide All EXCEPT <key's associated HUD element>
	
	ctrl + a = hide All
	shift + ctrl + a = show All


EXAMPLE: for a cinematic but playable wizarding experience, turn off all except the healthbar.
	"shift" + "ctrl" + "n" to hide all except floaty-healthbar-related stuff.
	Then "ctrl" + ("n" twice) to keep only the bar, no text.
	And maybe turn chat back on with "ctrl" + "c".


P.S.
	I just flat-out removed post-death tips because I don't think anyone cares for those.
	Also, if the health numbers break just press ctrl+n a few time and it should fix itself. lol